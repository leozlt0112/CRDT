class Type:
	PNCOUNTER = "pnc"
	RCOUNTER = "rc"
	ORSET = "os"
	RGRAPH = "rg"
	PERFORMANCE = "perf"
	BFTC = "bftc"
	DISCONNECT = "x"
